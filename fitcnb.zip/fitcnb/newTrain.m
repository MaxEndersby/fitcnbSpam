clear;
clc;

dataset = readtable('messagesTrain.xlsx');

trainMail = dataset(:,2);
trainLabel = dataset(:,3);
trainHeader = dataset(:,1);

MdlMail = fitcnb(trainMail,trainLabel);
MdlHeader= fitcnb(trainHeader,trainLabel);

testDataset = readtable('messagesTest.xlsx');

testMail = testDataset(:,2);
testHeader = testDataset(:,1);

trueLabel = testDataset(:,3);
trueLabel = table2cell(trueLabel);

resMessages = predict(MdlMail,testMail);
resSubjects = predict(MdlHeader,testHeader);
disp(resSubjects);